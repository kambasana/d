# Agentic World Graph (AWG) Master Documentation Pack

Version: 0.1.0-draft

## Purpose

AWG is a serious, persistent, geographically grounded world-simulation platform. It combines proven game/NPC architecture, agent-based modelling, geospatial systems, deterministic simulation, bounded AI reasoning, information provenance, social diffusion, scenario experimentation, and event-sourced replay.

It is not a chatbot village, a map full of unconstrained LLM characters, or a claim that generated text predicts real populations.

## Foundational equation

```text
Real or synthetic geography
+ deterministic simulation
+ proven NPC/ABM mechanisms
+ bounded agentic AI
+ human/social/economic systems
+ information provenance
+ persistent temporal world graph
= Agentic World Graph
```

## Foundational rule

> An AI model may propose an intention, plan, interpretation, or utterance. Only validated simulation systems may decide what actually happened.

## Key capabilities

- Build real, historical, hypothetical, or synthetic worlds and scenarios.
- Ground worlds in OSM geometry, gazetteers, places, streets, buildings, routes, and topology.
- Run offline using local OSM extracts, PostGIS, local Nominatim, local routing data, PMTiles/Protomaps, and Ollama.
- Swap AI providers such as Ollama and OpenRouter through adapters.
- Model agent lives, schedules, needs, goals, relationships, groups, organizations, resources, and information states.
- Enforce physically plausible movement, access, capacity, time, and causality.
- Separate objective world truth from what each agent knows or believes.
- Model information diffusion, trust, misinformation, social media, direct messages, reposts, comments, and fact checking.
- Emit a structured world and agent firehose for analytics, replay, audit, branch comparison, and future virtual social platforms.
- Simulate at multiple fidelity levels so large populations do not require every person to run a high-cost cognitive loop.
- Visualize populations through semantic zoom, clustering, density, flows, building occupancy, and individual inspection.

## Repository map

See `DOCUMENT-MAP.md` for the full reading order and dependency graph.

## Start here

Engineering and AI agents should read `AGENTS.md` before editing the pack.
