# Release and Versioning Strategy

## Versioned artifacts

Version independently where useful:

- application/runtime;
- domain/event schemas;
- plugin interfaces;
- individual plugins;
- scenario packages;
- data packages;
- model/prompt policies;
- documentation pack.

## Compatibility

Breaking schema/interface changes require migration notes and compatibility decision. Replays should record the schema/runtime version they require.

## Release evidence

A release candidate should include:

- changelog;
- migrations;
- SBOM/licence review;
- invariant/contract/integration test results;
- performance benchmark profile;
- known limitations;
- offline smoke test where supported;
- scenario/replay compatibility notes.
