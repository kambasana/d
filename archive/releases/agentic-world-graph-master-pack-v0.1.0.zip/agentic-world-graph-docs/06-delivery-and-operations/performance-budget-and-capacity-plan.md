# Performance Budget and Capacity Plan

## Principle

Use benchmark profiles rather than vague claims such as "supports millions of agents".

## Metrics

- population records loaded;
- S0/S1 updates per simulated hour;
- S2 scheduled agents active;
- S3 cognitive decisions per simulated hour;
- S4 embodied agents in local area;
- commands/events per second;
- spatial/routing queries per second;
- snapshot size/time;
- replay throughput;
- UI cluster query latency;
- map frame rate;
- inspector response latency;
- AI calls/tokens/latency per simulated hour;
- storage growth per simulated day.

## Budget strategy

Set different profiles for developer laptop, offline workstation, LAN cluster, and distributed deployment.

## AI cost control

- event-driven activation;
- novelty detection;
- deterministic/classical fallback;
- smaller model routing for simple tasks;
- cached/compiled policies;
- batchable inference where safe;
- explicit per-run token/call budgets.

## UI budget

- do not render all agents individually when clustered;
- use tile/cluster aggregation;
- virtualize long lists;
- avoid main-thread graph/layout work for large networks;
- stream only visible/selected detail.

Numeric targets are added only after baseline benchmarks are measured.
