# ADR-NNNN: Title

- Status: Proposed
- Date: YYYY-MM-DD
- Owners:
- Related requirements:
- Related documents:

## Context

What problem/constraint requires a durable decision?

## Decision drivers

- Driver 1
- Driver 2

## Options considered

### Option A
Pros, cons, risks.

### Option B
Pros, cons, risks.

## Decision

Chosen option and precise boundary.

## Rationale

Why this choice best satisfies the drivers.

## Consequences

### Positive

### Negative/trade-offs

## Risks and mitigations

## Migration / reversal strategy

## Acceptance evidence

Tests, benchmarks, prototype, or research evidence required.

## Supersedes / superseded by
