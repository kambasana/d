# Architecture Decision Records

Use ADRs for durable choices that affect multiple components, contracts, or invariants.

Naming:

```text
ADR-0001-short-title.md
```

Statuses: Proposed, Accepted, Superseded, Rejected.
