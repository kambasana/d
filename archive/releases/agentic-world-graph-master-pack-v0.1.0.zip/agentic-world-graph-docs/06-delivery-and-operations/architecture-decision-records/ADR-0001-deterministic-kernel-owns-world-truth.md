# ADR-0001: Deterministic Kernel Owns World Truth

- Status: Accepted for draft architecture
- Date: 2026-08-20
- Related requirements: AWG-INV-001, AWG-EVT-001

## Context

LLM-based agent simulations often allow generated narration to become state, which breaks physical constraints, causality, replay, and scientific inspectability.

## Decision

Authoritative world state is mutated only through validated domain commands/systems. AI outputs are proposals or content inputs and are untrusted until validated.

## Consequences

- More explicit schemas and systems are required.
- Model hallucinations cannot directly teleport agents or fabricate completed actions.
- Replay/debugging becomes tractable.
- AI providers can be replaced without changing world semantics.
