# Software Testing and Quality Strategy

## Test layers

### Unit tests
Pure domain calculations, reducers, validation rules, serializers, utility functions.

### Property/invariant tests
Examples:

- no location change without journey/intervention;
- resource quantities do not go negative unless model explicitly permits debt;
- exclusive capacity cannot exceed limit;
- belief updates never rewrite world truth;
- radial UI expansion cannot change position state.

### Contract tests
Every plugin implementation runs the same interface suite.

### Integration tests
OSM -> PostGIS -> routing -> journey -> event -> projection; social post -> exposure -> observation -> belief; scenario -> intervention -> branch -> comparison.

### Replay/determinism tests
Replay core events and recorded AI outputs to expected state checksums/projections.

### Load tests
Event throughput, active agents, cluster queries, spatial queries, replay speed, AI concurrency.

### Soak tests
Long simulated durations to expose event leaks, schedule drift, state growth, memory/queue leaks.

### Chaos/failure tests
Kill AI provider, routing adapter, projection consumer, or network service and verify authoritative state remains consistent/degrades safely.

### Security tests
Prompt injection, malformed plugin output, authorization, secret leakage, hostile social content, export permissions.

### Offline tests
Disable external networking and confirm configured offline scenario still works.

### UI tests
Accessibility, keyboard navigation, cluster semantics, branch/time state, visual regression, list alternatives, large-data virtualization.

## Quality gates

No MVP is done with known invariant failures. Failed validation is recorded, not hidden by changing the presentation.
