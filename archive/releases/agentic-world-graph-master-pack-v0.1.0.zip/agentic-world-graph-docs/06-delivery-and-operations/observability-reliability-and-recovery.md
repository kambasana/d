# Observability, Reliability, and Recovery

## Separate observability planes

### Simulation firehose
Domain events describing the world and agents.

### Software telemetry
Infrastructure metrics/traces/logs such as CPU, GPU, queue depth, model latency, errors, and health.

Do not conflate them.

## Health model

Each service/adapter exposes healthy, degraded, unavailable, and configuration/version status where applicable.

## Reliability principles

- authoritative writes are atomic/idempotent or have explicit compensation;
- projection failures cannot corrupt world truth;
- consumers maintain offsets/checkpoints;
- AI/routing failures produce bounded explicit outcomes;
- snapshots are validated before relying on them;
- restore includes event continuity/integrity checks.

## Recovery

Define per deployment:

- event-store backup/durability;
- snapshot schedule;
- spatial database backup;
- scenario/data/model package checksums;
- restore test cadence;
- RPO/RTO targets when productionized.

## Debugging

A developer should be able to trace:

```text
observation -> belief/goal -> decision policy/model call -> command -> validation -> events -> state projection
```

for selected important agent actions.
