---
title: MVP Roadmap and Definition of Done
document_id: AWG-OPS-001
status: draft
normative: true
---

# MVP Roadmap and Definition of Done

## Delivery rule

Do not start at planet scale. Prove invariants, replay, offline operation, and spatial causality in a bounded district/city slice before scaling.

## MVP 0 - Constitution and executable contracts

### Scope
- accepted simulation constitution;
- canonical terminology/domain entities;
- command/event envelope drafts;
- scenario package draft;
- plugin interface draft;
- traceability matrix;
- CI test skeleton.

### Done when
- no core domain component requires an LLM to execute basic world state transitions;
- every planned subsystem maps to owned contracts;
- invariants have acceptance-test IDs.

## MVP 1 - One district, no AI dependency

### Scope
- local OSM extract;
- PostGIS spatial model;
- local gazetteer;
- local routing;
- PMTiles/Protomaps map;
- simulation clock;
- buildings and entrances;
- scheduled agents;
- valid journeys/movement;
- basic smart objects/occupancy;
- immutable event firehose;
- snapshot/replay;
- semantic zoom and clusters;
- building occupancy inspector.

### Definition of done
- agents cannot teleport in invariant tests;
- travel time and route constraints are enforced;
- building entry uses valid transitions;
- replay reproduces deterministic world state;
- map clustering never alters positions;
- scenario operates with required services offline;
- 24-hour simulated run completes without state-integrity failures under target test population.

## MVP 2 - Classical NPC and social systems

### Scope
- needs/drives;
- schedules/routines;
- utility AI;
- state machine/behavior tree/StateTree pattern;
- GOAP/HTN planning where needed;
- action channels/concurrency;
- smart-object reservations;
- relationships/households/groups;
- organizations;
- resources/ownership/basic transactions;
- perception gating.

### Definition of done
- agents already produce coherent daily activity without LLM calls;
- impossible concurrent actions are blocked;
- resource/ownership conservation tests pass;
- perception tests prevent global-state knowledge leakage.

## MVP 3 - Bounded AI adapters

### Scope
- AIProviderAdapter;
- Ollama implementation;
- OpenRouter implementation;
- structured intent proposal;
- dialogue realization;
- claim extraction;
- memory summarization;
- bounded option ranking;
- model provenance;
- deterministic fallback/degraded behavior.

### Definition of done
- switching Ollama/OpenRouter does not change domain schemas;
- malformed/timeout model output cannot mutate world state;
- recorded model output can be replayed without provider call;
- model/provider/prompt-policy versions are traceable.

## MVP 4 - Information world and virtual social platform

### Scope
- claims/evidence/beliefs;
- contextual trust;
- direct messages/group communication;
- public posts/comments/reposts/reactions;
- exposure/feed mechanics;
- information-space-only actors;
- bad actors/deception;
- fact-check/contact-source actions;
- provenance graph;
- information-space UI.

### Definition of done
- A->B->C->post->repost chains are reconstructable;
- belief is separate from world truth;
- social reactions do not imply belief automatically;
- corrections/retractions preserve original history;
- agents cannot know unexposed claims.

## MVP 5 - Multi-resolution scale and experimentation

### Scope
- S0-S4 fidelity levels;
- cohort/individual promotion/demotion;
- event-driven activation;
- distributed/partitioned execution where required;
- scenario branch comparison;
- validation/calibration framework;
- sensitivity runs;
- performance/cost dashboards.

### Definition of done
- scale benchmarks define population records vs active cognition separately;
- promotion/demotion conserves key state/resources;
- branch comparison distinguishes intervention effects from seed/model variance;
- validation reports expose limitations and uncertainty.

## Phase gate template

Every MVP gate must list:

- objectives;
- in-scope/non-goals;
- dependencies;
- acceptance tests;
- performance target;
- security/offline target;
- validation evidence;
- documentation complete;
- known limitations;
- unresolved risks;
- release decision.
