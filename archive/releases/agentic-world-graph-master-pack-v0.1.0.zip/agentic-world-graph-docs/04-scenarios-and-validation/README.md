# 04 - Scenarios and Validation

This area turns worlds into reproducible experiments. It defines scenario packages, interventions, branch comparisons, calibration, validation, uncertainty, and sensitivity analysis.
