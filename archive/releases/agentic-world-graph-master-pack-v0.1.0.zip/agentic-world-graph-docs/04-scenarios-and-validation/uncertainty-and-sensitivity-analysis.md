# Uncertainty and Sensitivity Analysis

## Types of uncertainty

- input/data uncertainty;
- population synthesis uncertainty;
- stochastic behavioral variation;
- model parameter uncertainty;
- structural/model-choice uncertainty;
- LLM/provider nondeterminism;
- measurement uncertainty;
- scenario-assumption uncertainty.

## Typed randomness

Do not use a generic "randomness" knob. Maintain named mechanisms such as:

```text
perception_noise
memory_decay
travel_time_variation
decision_tie_breaking
communication_failure
information_mutation
population_sampling
environmental_variation
```

Each has explicit distribution/rules and named random stream.

## Seed strategy

Use world/scenario/region/system/agent-level streams as appropriate. Record enough metadata to reproduce stochastic sequences without assuming one global RNG is sufficient.

## Repeated runs

A scenario conclusion should be tested across seeds when stochastic mechanisms materially affect outcomes. Report distributions, not only a favorable single run.

## Model sensitivity

Repeat controlled subsets with alternative AI providers/models/prompt policies when AI materially influences outcomes. If outcomes swing widely, report that as model sensitivity rather than hiding it.

## Intervention robustness

Compare effect size against baseline variance. An intervention whose observed effect is smaller than ordinary seed/model variance should not be described as robust without further evidence.
