---
title: Scenario Definition and Experiment Protocol
document_id: AWG-SCN-001
status: draft
normative: true
---

# Scenario Definition and Experiment Protocol

## Scenario is data, not a prompt

A scenario is a versioned package containing enough information to reconstruct the intended experiment.

## Required scenario metadata

- scenario_id and version;
- title/purpose;
- intended use and non-use;
- base world and geographic extent;
- simulation start time/calendar/time zone;
- population/cohort inputs and synthesis method;
- organizations/institutions;
- infrastructure/resources;
- social/information networks;
- enabled domain systems;
- plugin versions/configurations;
- AI model/prompt-policy references;
- random seeds/streams;
- initial conditions;
- scheduled exogenous events;
- explicit interventions;
- measurements/KPIs;
- validation datasets/targets;
- stop conditions;
- known assumptions/limitations.

## Branch structure

```text
Baseline
├── Branch A: road closure
├── Branch B: price intervention
└── Branch C: information intervention
```

Branches share history to the declared branch point. Differences after the branch point must be attributable to interventions, randomness, model nondeterminism, or changed configuration that is explicitly recorded.

## Intervention types

Examples:

- close road/bridge/building;
- change public transport;
- remove electricity/service;
- change weather/environment;
- change price/resource availability;
- introduce policy/law;
- change organizational leadership;
- create public message/news/social post;
- introduce misinformation/bad actor;
- add/remove employer/service;
- trigger disaster/infrastructure failure.

The scenario engine changes conditions; it does not directly script every agent response.

## Experiment run record

Each run records:

- run_id;
- scenario/version;
- branch;
- execution start/end;
- code/build/version;
- plugin/model versions;
- seeds;
- source dataset versions;
- configuration hashes;
- hardware/runtime metadata relevant to reproducibility;
- snapshots/event ranges;
- validation outputs.

## Stop conditions

Examples include fixed simulation horizon, event condition, convergence criterion, resource exhaustion, or operator stop. Stop reason is recorded.
