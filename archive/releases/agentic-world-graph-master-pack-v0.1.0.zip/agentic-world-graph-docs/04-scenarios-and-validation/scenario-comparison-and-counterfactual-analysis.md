# Scenario Comparison and Counterfactual Analysis

## Goal

Compare branches without pretending that one simulation run proves causality in the real world.

## Comparison requirements

- same pre-branch history;
- declared intervention differences;
- matched or deliberately varied seeds;
- matched software/plugin/model versions unless the comparison is explicitly about those versions;
- common measurement definitions;
- confidence/uncertainty reporting.

## Views

Compare:

- world-state trajectories;
- population aggregates;
- selected agents;
- journeys/mobility;
- organizations/economy;
- information cascades;
- claims/beliefs;
- resource/infrastructure states;
- model-call usage/cost;
- validation metrics.

## Causal language

Use cautious wording such as "within this model, under these assumptions, the branch produced..." unless external validation justifies stronger claims.
