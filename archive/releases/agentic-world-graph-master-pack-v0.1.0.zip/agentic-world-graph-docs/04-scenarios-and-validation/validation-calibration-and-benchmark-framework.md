---
title: Validation, Calibration, and Benchmark Framework
document_id: AWG-SCN-002
status: draft
normative: true
---

# Validation, Calibration, and Benchmark Framework

## Principle

AWG must distinguish software correctness from model validity. A coherent story is not evidence that the simulation is empirically credible.

## Validation layers

### 1. Software verification
Does the implementation obey its declared rules, schemas, invariants, and deterministic transitions?

### 2. Structural/model validation
Are the mechanisms appropriate for the phenomenon and correctly connected?

### 3. Empirical calibration
Do selected distributions/outcomes match relevant observed data within declared tolerance?

### 4. Out-of-sample validation
Can calibrated models reproduce withheld locations, time periods, or scenarios?

### 5. Human comparison
Where human behavior is claimed, compare with human data/baselines rather than only LLM judges.

### 6. Sensitivity/uncertainty
How much do results change under seeds, model/provider, prompt, parameters, data assumptions, activation rates, and structural choices?

## Domain validation

### Geography/mobility
- route validity;
- distance/time distributions;
- mode constraints;
- entrance/barrier compliance;
- congestion/rerouting behavior;
- indoor/outdoor continuity.

### Human activity
- sleep/work/time-use distributions;
- household/activity patterns;
- trip/activity duration;
- resource use;
- response to schedule disruptions.

### Information diffusion
- exposure mechanics;
- transmission probability/model;
- mutation/correction;
- source trust;
- repost/comment behavior;
- fact-check pathways;
- cascade size/speed when empirical references exist.

### Agent cognition
- goal/action consistency;
- precondition compliance;
- memory provenance;
- belief/truth separation;
- response stability;
- failure/fallback behavior.

### Organizations/economy
- membership/governance rules;
- resource conservation;
- transaction validity;
- market/institution behavior for selected scenarios.

## Research benchmarks

Use existing systems/papers as targeted benchmarks, not as blanket validation. Examples from the research pack include Generative Agents, SOTOPIA, 360CityArena, OASIS, Concordia, AgentSociety, AgentTorch/Large Population Models, CityBehavEx, and established NPC/game architectures.

## Reporting

Every serious scenario result should publish:

- model scope;
- calibration data;
- validation metrics;
- failed tests/gaps;
- sensitivity results;
- uncertainty intervals/distributions;
- model/provider versions;
- known limitations;
- whether output is descriptive, exploratory, or predictive.

## Prohibited validation shortcut

LLM-as-judge may be supplementary. It cannot be the sole evidence for physical, behavioral, social, or predictive validity.
