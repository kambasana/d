# Linear Project Cross-Reference

## Project

- Name: AWG - Agentic World Graph
- Linear project ID: `a10f3a05-d977-49f8-b3a1-9de406231929`
- Project URL: https://linear.app/elenta/project/awg-agentic-world-graph-4dda61e419dd
- Team: Elenta (`ELE` issue key)
- Documentation prefix: `AWG`

## Linear project document

- AWG Documentation Map & AI Agent Instructions
- https://linear.app/elenta/document/awg-documentation-map-and-ai-agent-instructions-511aa8ee192d

## Milestones

1. AWG 1 - Foundation & Governance
2. AWG 2 - Domain Model
3. AWG 3 - Platform Architecture
4. AWG 4 - Scenarios & Validation
5. AWG 5 - UI/UX & World Explorer
6. AWG 6 - Delivery & Operations
7. AWG 7 - Executable Contracts

## Seeded Linear issues

- ELE-136 - Review and accept simulation constitution
- ELE-137 - Finalize canonical world model and ontology
- ELE-138 - Finalize spatial world, mobility and building specification
- ELE-139 - Finalize agent runtime and proven NPC decision hierarchy
- ELE-140 - Finalize information, trust, provenance and social diffusion model
- ELE-141 - Finalize command, event, firehose and replay contract
- ELE-142 - Finalize plugin/adaptor SDK and provider neutrality
- ELE-143 - Finalize multi-resolution simulation, storage and offline topology
- ELE-144 - Finalize scenario experiment and counterfactual protocol
- ELE-145 - Finalize validation, calibration and sensitivity framework
- ELE-146 - Finalize World Explorer, semantic zoom and design system
- ELE-147 - Review MVP roadmap, testing and performance gates
- ELE-148 - Convert normative specs into executable schemas

Linear retains the Elenta team issue prefix `ELE`. The AWG project name, labels, document IDs, milestones, and issue titles provide the project-specific prefixing.
