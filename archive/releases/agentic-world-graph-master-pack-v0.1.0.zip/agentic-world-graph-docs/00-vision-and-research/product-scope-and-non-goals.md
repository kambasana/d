# Product Scope and Non-Goals

## In scope

- Persistent geographically grounded world simulation.
- Real and synthetic OSM-like worlds.
- Multi-agent lives, groups, institutions, economies, and information networks.
- Offline-first operation where configured.
- Scenario interventions and counterfactual branches.
- World/agent firehose and replay.
- Modular AI and infrastructure adapters.
- Multiple levels of simulation and visualization fidelity.
- Evidence-based validation and explicit uncertainty.

## Non-goals

AWG is not:

- a guaranteed future prediction engine;
- a replacement for validated specialist scientific models;
- an always-on LLM for every simulated person;
- a claim to perfectly model human psychology;
- a chatbot town with decorative map markers;
- a system where natural-language narration directly edits authoritative state;
- a single graph database containing all workloads;
- dependent on one AI vendor, map provider, routing engine, or database;
- dependent on permanent internet access;
- a visual system that renders every agent individually at every map scale;
- a platform where demographic labels become personality stereotypes.
