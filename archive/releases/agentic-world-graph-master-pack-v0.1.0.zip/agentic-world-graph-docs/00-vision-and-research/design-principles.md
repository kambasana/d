# AWG Design Principles

1. **Simulation first, AI second.** AI augments bounded reasoning and language; it does not replace world mechanics.
2. **Nothing teleports.** People, objects, consequences, and information require valid paths through space, time, systems, or communication networks.
3. **World truth is separate from belief.** Agents act on what they know or believe, not privileged simulator truth.
4. **Established mechanics before invention.** Prefer proven game/NPC/ABM patterns for perception, planning, action, navigation, scheduling, concurrency, and debugging.
5. **Typed actions over prose.** Natural language can propose; typed commands and deterministic systems execute.
6. **Event-sourced observability.** Important actions and state transitions are machine-readable and replayable.
7. **Multi-resolution by design.** Distant populations can be aggregated; selected/local agents can become highly detailed.
8. **Visualization is a projection.** Clusters, heatmaps, radial expansions, and semantic zoom do not change simulation state.
9. **Offline is architectural.** Core scenarios can be packaged with local geography, routing, maps, models, and storage.
10. **Adapters protect the core.** Providers are replaceable implementations, not domain concepts.
11. **Randomness is controlled.** Noise represents uncertainty and variation within constraints, never unexplained rule-breaking.
12. **Validation beats believability.** Attractive conversations and animations are not evidence of model correctness.
