# 00 - Vision and Research

This area is primarily informative. It explains why AWG exists, what it is not, which established systems inform it, and which design principles were adopted.

Read `product-vision.md` first, then `product-scope-and-non-goals.md`, `design-principles.md`, and `research-and-prior-art.md`.
