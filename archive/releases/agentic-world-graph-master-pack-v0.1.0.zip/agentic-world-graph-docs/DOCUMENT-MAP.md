# AWG Document Map

## Root documents

- `README.md`: project overview.
- `AGENTS.md`: mandatory authoring instructions for AI agents and contributors.
- `glossary-and-controlled-vocabulary.md`: canonical terminology.
- `DOCUMENT-STATUS-MATRIX.md`: maturity and authority of each document.
- `REQUIREMENTS-TRACEABILITY-MATRIX.md`: requirements to specifications, tests, and MVP phases.
- `CHANGELOG.md`: normative documentation changes.

## Area packs

### 00 - Vision and research
Informative context, prior art, product scope, design principles, and research evidence.

### 01 - Governance and safety
Normative constitution, security/privacy, risks, licences, data provenance, and model provenance.

### 02 - Domain model
Canonical world ontology, agents, information, space, organizations, economy, resources, and ownership.

### 03 - Platform architecture
System boundaries, commands/events/firehose/replay, storage, plugins, scaling, and offline deployment.

### 04 - Scenarios and validation
Scenario packaging, experiment protocol, calibration, uncertainty, sensitivity, and counterfactual comparison.

### 05 - UI and UX
World explorer, design system, map semantics, clustering, inspectors, timeline, accessibility, and replay UX.

### 06 - Delivery and operations
MVP roadmap, testing, performance, reliability, release strategy, and ADRs.

### 07 - Machine-readable contracts
The future source of JSON Schema, event schemas, plugin manifests, and other executable contracts. Initial README files define ownership and scope.

### 08 - Examples
Worked examples that connect multiple specifications end-to-end.

### 09 - Templates
Reusable templates for scenarios, plugins, validation, data sources, risks, and research evidence.

## Normative dependency order

```text
Simulation Constitution
        |
        v
Canonical World Model + Glossary
        |
        +--> Spatial Model
        +--> Agent Runtime
        +--> Information/Trust Model
        +--> Organizations/Economy
        |
        v
Command/Event/Replay + Plugin Contracts
        |
        +--> Scaling
        +--> Storage/Projections
        +--> Deployment
        |
        v
Scenario Protocol + Validation
        |
        v
UI/UX + Delivery/Operations
```
