# Validation Report Template

## Scenario/model version

## Intended claim being validated

## Data/reference baseline

## Calibration method

## Metrics and thresholds

## Results

## Out-of-sample results

## Sensitivity analysis

## Uncertainty

## Failed tests/gaps

## Known limitations

## Conclusion and permitted interpretation
