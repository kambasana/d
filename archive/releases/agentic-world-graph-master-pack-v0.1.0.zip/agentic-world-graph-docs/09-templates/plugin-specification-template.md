# Plugin Specification Template

- Adapter family:
- Plugin ID:
- Version:
- Interface version:
- Licence:

## Capabilities

## Configuration schema

## Inputs/outputs

## Errors/timeouts/retries

## Offline support

## Determinism

## Security/capability permissions

## Health checks

## Provenance and data ownership

## Compatibility tests

## Fallback behavior
