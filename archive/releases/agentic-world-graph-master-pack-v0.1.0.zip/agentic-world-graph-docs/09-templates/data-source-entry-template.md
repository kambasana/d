# Data Source Entry Template

- Dataset ID:
- Name/provider:
- Original source:
- Retrieval date:
- Coverage/time period:
- Licence/attribution:
- Provenance class:
- Transformations/version:
- Quality/gaps:
- Sensitive classification:
- Geographic precision:
- Bias considerations:
- Permitted uses:
- Dependent scenarios:
- Owner/review date:
