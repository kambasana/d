# Risk / Assumption Entry Template

- ID:
- Type: Risk | Assumption
- Category:
- Description:
- Cause:
- Consequence:
- Likelihood:
- Impact:
- Owner:
- Mitigation:
- Contingency:
- Trigger:
- Evidence:
- Residual risk:
- Status:
- Review date:
- Affected documents/MVP phases:
