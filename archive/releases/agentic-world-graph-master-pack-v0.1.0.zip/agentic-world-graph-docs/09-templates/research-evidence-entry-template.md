# Research Evidence Entry Template

- Evidence ID:
- Paper/system/source:
- Date/version:
- URL/reference:
- Domain:
- What it actually demonstrates:
- Reusable mechanism/pattern:
- What must not be inferred:
- Licence/reuse implications:
- AWG documents influenced:
- Review date:
