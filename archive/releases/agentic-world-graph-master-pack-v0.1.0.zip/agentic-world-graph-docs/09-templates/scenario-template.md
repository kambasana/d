# Scenario Template

## Metadata
- Scenario ID:
- Version:
- Purpose:
- Intended use:
- Non-use:

## World and time
- Geography/data package:
- Extent:
- Start time/time zone:

## Population
- Source/synthesis method:
- Cohorts/agents:

## Systems/plugins/models

## Seeds/random streams

## Initial conditions

## Scheduled events/interventions

## Measurements

## Validation targets

## Stop conditions

## Assumptions and limitations
