# Glossary and Controlled Vocabulary

This file defines canonical project terms. Use these terms consistently in code, schemas, UI copy, and specifications.

| Term | Canonical meaning | Do not use interchangeably with |
|---|---|---|
| Agent | Persistent simulated actor with identity, state, constraints, history, and action capability | LLM, chatbot, process, cohort |
| Population cohort | Aggregate or archetype representation of multiple people | Fully instantiated individual agent |
| World truth | Authoritative state determined by simulation systems | Agent belief, UI projection |
| Agent belief | An agent-specific proposition with confidence/provenance | Objective truth |
| Observation | Information made available to an agent through a valid perception or access path | Global state dump |
| Claim | A proposition communicated or recorded with source lineage | Verified fact |
| Evidence | Observation, record, or other support linked to a claim | Belief |
| Intent | Proposed desired action or outcome before validation | Completed action |
| Command | Typed request submitted to simulation validation/execution | Free-form narration |
| Domain event | Immutable record that a validated state transition or relevant occurrence happened | Telemetry log |
| Firehose | Structured stream of simulation domain events and agent/world activity | Software monitoring telemetry |
| Projection | Derived read model for maps, dashboards, search, feeds, or analytics | Authoritative source of truth |
| Simulation clock | Authoritative in-world time | Wall-clock runtime time |
| Scenario | Versioned package of world inputs, assumptions, interventions, measurements, and execution settings | Prompt |
| Intervention | Explicit scenario/operator change to world conditions | Hidden forced outcome |
| Place | Identified spatial entity with geometry and relationships | Mere text label |
| Gazetteer | Name/address/place lookup system | Routing engine, spatial authority |
| Route | Valid traversable path produced or validated by mobility systems | Straight-line teleport |
| Journey | Stateful movement process through one or more route legs over time | Location assignment |
| Co-location | Multiple agents or entities occupying the same logical place or near-identical interaction point | Geographic aggregation |
| Geographic cluster | UI aggregation of agents spread across an area | Shared physical location |
| Analytical cluster | UI grouping produced by a query/filter | Physical cluster |
| Semantic zoom | Changing the kind of information shown as view scale changes | Simply resizing markers |
| Simulation fidelity | Depth/cost of entity simulation | Visualization fidelity |
| Visualization fidelity | How much detail the UI renders | Cognitive simulation level |
| Smart object | World object/place exposing typed affordances, capacity, access, reservation, and effects | Decorative prop |
| Trust | Contextual assessment of source reliability by agent/domain/channel/history | Universal single reputation score |
| Provenance | Traceable origin and transformation history of data, claims, events, or model outputs | Citation alone |
| Synthetic world | Generated geography and society that still obeys coherent spatial/topological rules | Unstructured fictional place names |
| LLM adapter | Provider-neutral interface for bounded model capabilities | Core agent runtime |
| PMTiles | Offline-friendly tiled map archive/presentation source | Authoritative simulation geometry |
| Nominatim | OSM-oriented gazetteer and geocoder | Movement engine |
| Replay | Reconstructing a simulation using recorded events/model outputs/versioned inputs | Re-running with unknown changes |
| Branch | Counterfactual continuation from a known snapshot/event point | New unrelated scenario |
