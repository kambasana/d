# Plugin Contracts

Owner: AWG-PLAT-003.

Future manifests define adapter ID/version, interface version, capabilities, configuration schema, offline support, errors, health, permissions, determinism, licence/provenance, and compatibility test suite.
