# Event Contracts

Owner: AWG-PLAT-002.

Future schemas define immutable event envelope, event families, causal/parent links, simulation time, branch, location, provenance, plugin/model/random-stream references, and payload versioning.
