# Command Contracts

Owner: AWG-PLAT-002.

Future schemas define command envelope, typed arguments, source/authority, validation metadata, and idempotency/correlation fields. Free-form LLM text is never itself an executable command.
