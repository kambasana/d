# Claim and Provenance Contracts

Owner: AWG-DOM-004.

Future schemas define claim proposition references, source lineage, channels, evidence, confidence, trust assessments, contradictions, corrections/retractions, and agent-specific belief links.
