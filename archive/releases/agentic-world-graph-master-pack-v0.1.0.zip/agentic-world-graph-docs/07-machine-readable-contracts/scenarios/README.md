# Scenario Contracts

Owner: AWG-SCN-001.

Future schemas define scenario package metadata, world/data dependencies, plugins/models, seeds, interventions, measurements, branch settings, stop conditions, assumptions, and validation references.
