# Agent Contracts

Owner: AWG-DOM-003.

Future schemas define persistent agent identity/state references without making the LLM provider part of agent identity. Detailed state may be split across services/stores.
