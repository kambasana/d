# 07 - Machine-Readable Contracts

This area will contain executable schemas/manifests derived from the normative Markdown specifications.

Rule: Markdown explains semantics; schemas enforce structure. A schema must not invent behavior inconsistent with its normative source.

Initial contract families:

- commands
- events
- scenarios
- agents
- plugins
- claims/provenance
- world entities
