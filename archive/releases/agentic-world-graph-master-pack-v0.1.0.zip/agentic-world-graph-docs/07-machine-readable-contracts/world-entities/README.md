# World Entity Contracts

Owner: AWG-DOM-001 and AWG-DOM-002.

Future schemas define stable entity IDs/references, place/building/entrance relationships, resources/ownership, temporal validity, and provenance classes.
