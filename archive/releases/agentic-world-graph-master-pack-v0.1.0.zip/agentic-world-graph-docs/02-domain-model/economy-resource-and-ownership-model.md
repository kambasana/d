# Economy, Resource, and Ownership Model

## Purpose

Economic/social scenarios require explicit resources and ownership rather than conversational claims that an agent "has" something.

## Core concepts

- resource type and quantity;
- asset/object identity;
- ownership/control/possession;
- money/accounting unit;
- price/cost;
- inventory;
- production/consumption;
- transaction;
- contract/obligation;
- capacity/scarcity;
- market/institution rules.

## Ownership

Ownership and possession are separate relationships. A rented car can be possessed by one agent while owned by another entity.

## Transactions

Transactions are typed, validated, time-stamped events. They check availability, permissions, quantities, payment/consideration where required, and update state atomically or through explicit failure/compensation events.

## Scarcity and behavior

Resources influence plans and feasible actions. Agents cannot consume or transfer resources that do not exist in their accessible inventory/state.

## Economic LOD

Large populations may use aggregate market/demand models while local/selected agents use individual transactions. Promotion/demotion must conserve quantities and avoid double counting.
