# Organization, Group, and Institution Model

## Social hierarchy

AWG supports overlapping structures rather than one rigid tree:

```text
Civilization / society
Government / institution
Organization
Faction / community
Household
Group / team
Individual
```

An agent can belong to multiple structures simultaneously.

## Organization state

An organization may have:

- identity/type;
- members and roles;
- leadership/governance;
- resources and property;
- territory/places;
- policies/rules;
- objectives;
- internal/external relationships;
- reputation/trust by observers;
- communication channels;
- decision mechanisms;
- schedules/operations;
- history and events.

## Group actions

Organizations/groups can create commands through explicit governance mechanisms rather than being treated as a single giant LLM personality. Examples include leader authority, voting, delegated roles, policy rules, committees, market mechanisms, or bounded organization-level planners.

## Membership

Join, leave, expel, hire, fire, appoint, elect, and transfer actions generate persistent relationship events.

## Knowledge

Organization knowledge is not automatically identical to every member's knowledge. Access depends on role, communication, records, classification, and propagation.
