---
title: Agent Runtime, Cognition, and Action Model
document_id: AWG-DOM-003
status: draft
normative: true
---

# Agent Runtime, Cognition, and Action Model

## Principle

Agents should live inside the simulation continuously, even when no LLM is being called. Their state persists through schedules, actions, relationships, obligations, memories, world events, and time.

## Agent composition

```text
Agent
├── Identity/provenance
├── Body/physical condition
├── Location/mobility state
├── Roles/obligations
├── Needs/drives
├── Schedule/routines
├── Goals
├── Perception filters
├── Working memory / blackboard
├── Episodic memory
├── Semantic knowledge
├── Claims/evidence/beliefs
├── Relationships/trust
├── Utility evaluation
├── Planner (GOAP/HTN/StateTree/other adapter)
├── Action executor
├── Communication policy
└── AI reasoning/dialogue adapters
```

## Decision hierarchy

Use the cheapest reliable mechanism first:

```text
1. hard rule / invariant
2. continue existing action
3. schedule/routine
4. state machine / StateTree / behavior tree
5. utility selection
6. GOAP/HTN planning
7. cached/compiled learned policy
8. bounded small-model reasoning
9. bounded larger-model reasoning
10. operator escalation if configured
```

LLM calls should occur at novelty boundaries, not every simulation tick.

## Proven NPC patterns

Prefer established mechanisms before prompt reinvention:

- perception sensors/events;
- blackboard/typed working memory;
- utility AI;
- state machines/behavior trees/StateTree;
- GOAP/HTN preconditions/effects/costs;
- smart objects and reservations;
- action channels/concurrency;
- event-driven activation;
- context-aware dialogue;
- director/scenario separation;
- debugging/traceability.

## Actions

An executable action defines:

- action type;
- actor;
- arguments;
- preconditions;
- permissions;
- required resources/capabilities;
- resource locks/reservations;
- expected duration;
- effects on success;
- observations generated;
- cancellation/interruption rules;
- failure states;
- event outputs.

Example:

```text
TravelToPlace(destination, mode)

Preconditions:
- actor can move
- destination exists
- mode is available
- route is valid

Execution:
- mobility system creates and advances a journey

Completion:
- arrival event at valid destination transition/entrance
```

The LLM can propose the command. It cannot announce success and bypass execution.

## Action concurrency

Use explicit action channels such as:

```text
locomotion
posture
hands
attention
speech
digital_activity
long_running_obligation
```

Compatibility rules prevent impossible combinations while allowing realistic concurrent behavior such as sitting, eating, and conversing where constraints allow.

## Needs and goals

Humanistic systems must be explicit and configurable. They may include hunger, fatigue, safety, social obligations, work, money, care responsibilities, habits, commitments, preferences, and current emotional/physical state. Do not infer a complete psychology from demographics alone.

## Memory

Canonical memory is structured data with time and provenance. Embeddings are retrieval aids, not memory truth.

Memory types can include:

- episodic experiences;
- semantic knowledge;
- social/relationship history;
- procedures/skills;
- commitments/plans;
- claim/evidence references.

Memory decay/forgetting is a model rule with recorded parameters, not arbitrary deletion.

## Dialogue

Dialogue generation receives only permitted/available agent knowledge plus context and communication goals. It may express uncertainty and deception when the agent model permits it, but it must not invent unavailable factual knowledge merely to make text interesting.

## AI failure behavior

Malformed output, timeout, unavailable provider, or unsafe tool request cannot mutate world state. The runtime uses configured fallback, deterministic/default action, wait/defer behavior, or an explicit failure event.
