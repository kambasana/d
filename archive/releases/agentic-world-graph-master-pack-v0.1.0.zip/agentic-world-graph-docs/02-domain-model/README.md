# 02 - Domain Model

Normative definitions of what exists in an AWG world and how those entities behave. These specifications depend on the simulation constitution and glossary.

Recommended order:

1. Canonical world model and ontology
2. Spatial world, mobility, and buildings
3. Agent runtime and cognition
4. Information, trust, and provenance
5. Organizations, groups, institutions
6. Economy, resources, and ownership
