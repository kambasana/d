---
title: Spatial World, Mobility, and Building Specification
document_id: AWG-DOM-002
status: draft
normative: true
---

# Spatial World, Mobility, and Building Specification

## Spatial authority

For real-world scenarios, authoritative spatial state is built from versioned OSM-derived geometry/topology plus approved supplemental datasets. PostGIS is the default candidate for queryable spatial truth. Routing/navigation systems derive traversable networks from approved sources.

PMTiles/Protomaps is a first-class offline presentation/distribution option, not authoritative topology.

Nominatim is a gazetteer for place/address resolution, not a physical traversal engine.

## Required spatial concepts

```text
Planet -> Region -> City -> District -> Place -> Building -> Floor -> Room/Area -> Object
```

The hierarchy is semantic, not always strictly administrative. An agent should be able to answer both coordinate and place-context questions.

## OSM provenance

Preserve where available:

- node/way/relation IDs;
- extract timestamp/version;
- original tags;
- original and derived geometry references;
- transformation pipeline/version;
- access/routing interpretation;
- synthetic/observed status.

## Synthetic geography

A synthetic world must still provide coherent:

- roads and paths;
- intersections/topology;
- buildings and entrances;
- addresses/places or equivalent naming system;
- administrative/spatial containment;
- transport networks;
- barriers and crossings;
- traversable indoor/outdoor transitions.

Synthetic agents must not treat invented place names as teleport destinations.

## Journey state machine

```text
Planned
  -> Preparing
  -> Departed
  -> InTransit
  -> Rerouting / Waiting / Interrupted (optional)
  -> Arrived
  -> Completed

or
  -> Failed / Cancelled
```

A journey records origin, destination, mode, route/legs, departure, estimated/actual times, route changes, interruptions, and arrival.

## Layered mobility engines

Candidate architecture:

```text
Regional/multimodal route: Valhalla-like adapter
Activity plans/replanning: MATSim-like patterns/adapter
Microscopic traffic: SUMO-like adapter
Local/building navigation: Recast/Detour-like navmesh
Immediate movement/collision: local controller/physics
```

No single engine is assumed to solve every scale.

## Movement constraints

An agent cannot:

- travel three miles in one second;
- pass through inaccessible geometry;
- cross a river without a valid crossing/mode;
- enter a building without a valid entrance/transition unless an explicit exceptional rule exists;
- use a transport mode without access/capability;
- occupy exclusive capacity already reserved by another entity;
- appear at a destination without journey/intervention history.

## Buildings

Buildings support:

- shell/footprint;
- entrances and access rules;
- floors/levels;
- rooms/areas;
- stairs/lifts/transitions;
- occupancy/capacity;
- smart objects/affordances;
- local navigation;
- queues and reservations;
- optional visibility/hearing models.

At street scale, a building may be represented by an occupancy count. At interior scale, the same occupants can resolve into floor/room/individual views.

## Co-location

Co-location is a world-state concept. UI radial expansion is only a selection projection. An expanded marker does not change physical position.

## Mobility events

Minimum event family:

```text
JourneyPlanned
JourneyStarted
RouteSelected
JourneyProgressed
JourneyDelayed
JourneyRerouted
JourneyInterrupted
JourneyArrived
JourneyCancelled
LocationEntered
LocationExited
AccessDenied
```

## Offline requirement

A packaged city scenario should be able to operate using local OSM extract, local spatial database, local gazetteer, local routing data, local PMTiles, and local model provider where configured.
