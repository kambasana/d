---
title: Information, Trust, Provenance, and Social Diffusion Model
document_id: AWG-DOM-004
status: draft
normative: true
---

# Information, Trust, Provenance, and Social Diffusion Model

## Purpose

Information is a first-class simulation substrate. Agents are not omniscient. Facts and claims move through physical, interpersonal, institutional, broadcast, and digital networks.

## Knowledge hierarchy

An agent distinguishes at least:

```text
direct experience
personal observation
trusted first-hand report
second-hand report
accessible record/news
public social post
repost/comment/reaction
unattributed rumor
inference
```

These are not equivalent evidence states.

## World truth vs belief

Example:

```text
World truth: electrical transformer failure

Agent A belief: transformer exploded
Agent B belief: building explosion
Agent C belief: terror attack
Agent D belief: unknown cause
Agent E belief: gas explosion
```

Agents act on their available beliefs, not on simulator-only truth.

## Claim object

A claim should support:

```text
claim_id
proposition
subject/entity references
asserted_by
original_source
source_chain
channel
created_at / received_at
location context
evidence references
confidence
trust assessment
corroboration
contradictions
dispute/retraction status
mutation parent/version
agent disposition
```

## Provenance chain example

```text
Physical event
  -> A directly observes event
  -> A tells B
  -> B tells C
  -> C creates public post
  -> D views and likes
  -> E reposts
  -> F comments and messages A for verification
  -> A may reply, ignore, clarify, contradict, or deceive
```

Every step is represented separately. A later analyst should be able to ask why F believed something and trace the answer back through C, B, A, and the original observation.

## Information mutation

Claims may change as they propagate:

```text
A: "I heard a bang and saw smoke."
B: "A said there may have been an explosion."
C: "Explosion reported downtown."
D: "Major explosion downtown."
E: "Attack happening downtown."
```

Lineage must be retained so mutation is inspectable.

## Trust

Trust is contextual:

```text
Trust(observer, source, domain, channel, situation, history)
```

An agent may trust another person about engineering and distrust them about politics. Trust can be influenced by prior accuracy, relationship, expertise, incentives, deception history, institutional role, and corroboration.

## Bad actors

Agents may be mistaken, biased, unreliable, manipulative, deceptive, malicious, coordinated, compromised, or opportunistic. Receiving agents are not automatically told that a claim is false. They evaluate it using their own evidence and trust mechanisms.

## Fact-checking as an action

Verification is not global magic. Agents may:

- contact witnesses;
- search accessible records;
- compare independent sources;
- ask specialists;
- visit a location if feasible;
- wait for official communication;
- ignore or challenge a claim.

Each action has time, access, cost, and possible failure.

## Information spaces

Physical and information spaces interact bidirectionally:

```text
PHYSICAL WORLD
  -> observations
INFORMATION WORLD
  -> beliefs/actions
PHYSICAL WORLD
```

Information can produce physical feedback loops such as panic buying, travel changes, crowd formation, or organizational response.

## Virtual social media

The platform supports simulated social systems with typed actions such as:

- create post/comment/reply;
- like/dislike/reaction;
- repost/quote-post;
- follow/unfollow;
- mention;
- direct message;
- group chat;
- block/mute/report;
- search;
- fact-check/contact source.

Social platform mechanics must model follow graphs, privacy, visibility, feed ranking, recommendation eligibility, recency, topic affinity, group membership, blocking, moderation, and platform-specific rules through adapters.

Do not ask an LLM to decide all feed exposure directly.

## Social action semantics

```text
viewed != understood
understood != believed
believed != endorsed
endorsed != liked
liked != reposted
reposted != motive known
```

Observable actions and inferred motives are stored separately.

## Information-space-only actors

The architecture may represent news organizations, bots, remote analysts, institutional accounts, automated alerts, and external commentators that primarily act in information space. Their identity/capability model must state whether they also have physical embodiment.

## Firehose events

Examples:

```text
ObservationCreated
ClaimAsserted
ClaimReceived
ClaimCorroborated
ClaimContradicted
BeliefUpdated
MessageSent
MessageDelivered
PostCreated
PostViewed
PostLiked
PostReposted
CommentCreated
FactCheckRequested
SourceContacted
ClaimCorrected
ClaimRetracted
```

Each event references time, actors, channel, claim/message/post IDs, causal parents, visibility/audience, and relevant location/provenance.
