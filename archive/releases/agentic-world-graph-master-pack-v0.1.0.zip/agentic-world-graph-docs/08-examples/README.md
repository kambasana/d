# 08 - Worked Examples

Examples are informative but must use normative terminology and valid event/command semantics. They are intended to become end-to-end acceptance fixtures later.
