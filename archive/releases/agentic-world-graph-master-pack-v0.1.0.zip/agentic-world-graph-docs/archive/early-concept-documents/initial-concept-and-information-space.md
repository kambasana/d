# Early Concept Synthesis - Preserved Informative Source

This document preserves the originating product ideas that were later normalized into the normative pack.

## World concept

AWG should build worlds and scenarios with real or synthetic geography, OSM gazetteer/place/road/building semantics, offline Protomaps/PMTiles support, modular Ollama/OpenRouter AI providers, proven game/NPC mechanics, persistent agent lives, groups/organizations, physics/constraints, and a complete machine-readable event firehose.

Agents must understand physical space: travel takes time, routes must exist, entrances and barriers matter, and agents cannot randomly spawn at destinations after initialization.

## Information concept

Agents only know what reaches them. An event can be directly experienced by A, discussed with B, passed to C, posted publicly, then liked/reposted/commented on by others. Source lineage and claim mutation are preserved. Bad actors can inject misleading claims. Fact checking is an agent action and may involve contacting sources. A virtual social-media environment can include world inhabitants and information-space-only actors.

## Visualization concept

Do not render every person as a dot at every scale. Use semantic zoom, density, flow, count clusters, building occupancy, and individual markers at close range. When several agents truly share a location, a small co-location marker can expand radially around the point for selection without changing their authoritative physical positions.

## Randomness concept

Human systems need variation, but randomness is bounded and typed. It can influence perception, timing, tie-breaking, communication failure, travel variation, and information mutation. It cannot override geography, causality, access, or resources.
