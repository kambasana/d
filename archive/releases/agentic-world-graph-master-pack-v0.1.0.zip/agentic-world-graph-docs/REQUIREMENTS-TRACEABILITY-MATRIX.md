# AWG Requirements Traceability Matrix

This matrix is the index between project rules, specifications, acceptance tests, and delivery phases.

| Requirement | Summary | Source specification | Primary test/evidence | MVP |
|---|---|---|---|---|
| AWG-INV-001 | LLMs cannot directly mutate authoritative world state | Simulation Constitution | Command-boundary contract test | 3 |
| AWG-GEO-001 | Every non-initial position change requires a valid movement or explicit intervention path | Spatial World Specification | Movement invariant suite | 1 |
| AWG-GEO-002 | Travel consumes simulation time and respects route/mode constraints | Spatial World Specification | Route/time integration tests | 1 |
| AWG-INF-001 | Agent knowledge requires a valid perception, communication, record, memory, or inference path | Information/Trust Model | Epistemic provenance tests | 4 |
| AWG-INF-002 | World truth and agent belief remain separate | Information/Trust Model | Contradictory-belief scenario test | 4 |
| AWG-INF-003 | Likes, comments, reposts, exposure, belief, and endorsement are separate states | Information/Trust Model | Social action semantics tests | 4 |
| AWG-EVT-001 | Accepted commands emit immutable domain events | Command/Event Specification | Event contract tests | 1 |
| AWG-EVT-002 | Replay can use recorded LLM outputs without invoking the provider again | Command/Event Specification | Replay determinism test | 3 |
| AWG-PLG-001 | Core domain contracts are provider-neutral | Plugin SDK | Provider swap test | 3 |
| AWG-SCL-001 | Simulation fidelity is independent from visualization fidelity | Scaling Architecture | LOD transition tests | 5 |
| AWG-UX-001 | Geographic clusters summarize real member positions without moving them | Map Clustering Spec | Map interaction test | 1 |
| AWG-UX-002 | Co-location radial expansion is a selection aid, not physical relocation | Map Clustering Spec | UI/state consistency test | 1 |
| AWG-VAL-001 | Claims of realism require explicit validation evidence and uncertainty | Validation Framework | Validation report review | 5 |
| AWG-OPS-001 | Core city scenario can run without required internet access | Offline Deployment | Air-gapped smoke test | 1 |

Add rows whenever a normative requirement is introduced.
