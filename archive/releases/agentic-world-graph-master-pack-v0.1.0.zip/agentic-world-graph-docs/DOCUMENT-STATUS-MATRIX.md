# AWG Document Status Matrix

| Area | Document | Class | Status |
|---|---|---|---|
| Root | AGENTS.md | Normative authoring policy | Draft |
| Root | glossary-and-controlled-vocabulary.md | Normative reference | Draft |
| Governance | simulation-constitution-and-invariants.md | Normative | Draft |
| Governance | security-safety-privacy-and-misuse-model.md | Normative | Draft |
| Governance | risk-and-assumption-register.md | Register | Seeded |
| Governance | open-source-reuse-and-licensing-register.md | Register | Seeded |
| Governance | data-source-and-provenance-register.md | Register | Seeded |
| Domain | canonical-world-model-and-ontology.md | Normative | Draft |
| Domain | agent-runtime-cognition-and-action-model.md | Normative | Draft |
| Domain | information-trust-and-provenance-model.md | Normative | Draft |
| Domain | spatial-world-mobility-and-building-specification.md | Normative | Draft |
| Platform | command-event-firehose-and-replay-specification.md | Normative | Draft |
| Platform | plugin-adapter-sdk-and-compatibility-contracts.md | Normative | Draft |
| Platform | multi-resolution-simulation-and-scaling-architecture.md | Normative | Draft |
| Scenarios | scenario-definition-and-experiment-protocol.md | Normative | Draft |
| Scenarios | validation-calibration-and-benchmark-framework.md | Normative | Draft |
| UI/UX | ui-application-architecture-and-design-system.md | Normative | Draft |
| UI/UX | agent-map-clustering-and-semantic-zoom.md | Normative | Draft |
| Delivery | mvp-roadmap-and-definition-of-done.md | Normative delivery plan | Draft |
| Vision | research-and-prior-art.md | Informative | Existing source imported |

Statuses: Planned, Seeded, Draft, Review, Accepted, Superseded.
