# AWG Documentation Changelog

## 0.1.0-draft - 2026-08-20

- Created master documentation pack and AWG document ID scheme.
- Established deterministic-kernel authority and bounded-LLM architecture.
- Added OSM/PostGIS authoritative spatial model with PMTiles/Protomaps presentation role.
- Added agent epistemic state, information provenance, trust, diffusion, and virtual social media requirements.
- Added event firehose, replay, counterfactual branching, and model provenance principles.
- Added semantic zoom, geographic/co-location/analytical clustering, and radial overlap expansion.
- Added multi-resolution simulation and visualization separation.
- Added governance registers, MVP plan, testing, and validation structure.
