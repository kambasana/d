# 01 - Governance and Safety

This area contains project-wide rules and registers. The simulation constitution is normative and has precedence over lower-level specifications unless explicitly superseded through an accepted ADR and coordinated specification update.
