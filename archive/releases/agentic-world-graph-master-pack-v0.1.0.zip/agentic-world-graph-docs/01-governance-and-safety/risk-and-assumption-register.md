# Risk and Assumption Register

| ID | Type | Description | Consequence | Mitigation | Status |
|---|---|---|---|---|---|
| RISK-001 | Architecture | LLM behavior becomes de facto world authority | Physically/causally invalid simulation | Enforce typed command boundary and deterministic validators | Open |
| RISK-002 | Scale | Per-agent per-tick LLM calls dominate cost/latency | Cannot scale beyond demos | Event-driven activation, LOD, cached policies, classical NPC systems | Open |
| RISK-003 | Validation | Convincing dialogue is mistaken for human realism | Misleading scenario conclusions | Empirical calibration, benchmarks, uncertainty reports | Open |
| RISK-004 | Spatial | Map tiles used as authoritative topology | Invalid routes/access | Separate PostGIS/routing truth from PMTiles projection | Open |
| RISK-005 | Provenance | Agents receive global or unattributed information | Telepathic knowledge and invalid diffusion | Epistemic provenance and observation gating | Open |
| RISK-006 | Licensing | Copyleft/restricted components are reused without review | Distribution/commercial obligations | Licensing register and reuse gate | Open |
| RISK-007 | Privacy | Real-person data is over-specified or re-identifiable | Privacy/legal harm | Data minimization, access controls, synthetic defaults | Open |
| RISK-008 | UI | Thousands of markers obscure meaning | Unusable world explorer | Semantic zoom, clusters, density, occupancy drilldown | Open |
| ASSUMPTION-001 | Assumption | OSM is a primary spatial foundation for real-world scenarios | Coverage/quality varies by area | Preserve provenance and allow supplemental data adapters | Active |
| ASSUMPTION-002 | Assumption | Core deployment should support offline operation | Larger local storage/ops footprint | Package maps, gazetteer, routing, models, data locally | Active |
| ASSUMPTION-003 | Assumption | Human behavior needs stochastic variation | Seed sensitivity | Typed noise and repeated runs | Active |
