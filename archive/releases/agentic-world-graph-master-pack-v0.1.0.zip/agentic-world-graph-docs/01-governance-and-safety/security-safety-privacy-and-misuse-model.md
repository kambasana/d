# Security, Safety, Privacy, and Misuse Model

## Security boundaries

- LLM output is untrusted input until schema and domain validation pass.
- Agent-generated posts/messages can contain prompt-injection content and must never become privileged system instructions.
- Plugins run with least privilege and explicit capability declarations.
- Secrets and provider credentials stay outside scenario content and agent memory.
- Event exports, data sources, and plugins require access controls appropriate to deployment.

## Privacy

Real-person simulation requires explicit provenance, legal basis/permission where applicable, minimization, retention rules, and controls against re-identification. Synthetic personas must be labelled synthetic.

## Sensitive geography

The platform must support redaction, precision reduction, access restrictions, and export controls for sensitive locations or datasets.

## Misuse controls

High-consequence scenarios must state intended use, limitations, uncertainty, data quality, and model validation. Simulated outcomes must not be presented as guaranteed forecasts.

## Adversarial information

Bad actors may exist inside scenarios, but platform controls must distinguish simulated adversarial behavior from real platform abuse. Simulation content cannot gain code execution, credential access, or privileged control over the host.

## Audit

Record operator interventions, plugin/version changes, model configuration changes, privileged exports, and scenario branch creation.
