# Open Source Reuse and Licensing Register

This register is a review queue, not legal advice. Confirm exact versions and dependency licences before adoption.

| Component/system | Intended use | Known licence/status from research | Reuse mode | Review decision |
|---|---|---|---|---|
| Google DeepMind Concordia | Agent/component and environment design patterns; possible library evaluation | Apache-2.0 project | Pattern first; code subject to review | Review |
| OASIS | Social platform actions, graph mechanics, activation/recommendation ideas | Apache-2.0 project | Pattern/API evaluation | Review |
| AgentSociety 2 | Experiment/replay/distributed orchestration patterns | Apache-2.0 except noted repo areas | Pattern and selective evaluation | Review |
| CityBehavEx | Validation/mobility architecture ideas | AGPL-3.0 repository | Pattern/research only unless approved | Restricted review |
| Recast/Detour | Local navigation/navmesh | Open-source; verify exact repo licence/version | Candidate dependency | Review |
| SUMO | Microscopic traffic | Verify exact distribution/licence requirements | Adapter candidate | Review |
| Valhalla | Regional/multimodal routing | Verify exact version/dependencies | Adapter candidate | Review |
| MATSim | Mobility planning patterns/possible integration | Verify exact modules/licences | Pattern or adapter | Review |
| PostGIS | Authoritative spatial database | Verify deployment version/licence | Candidate dependency | Review |
| osm2pgsql | OSM import/transformation | Verify version/licence | Candidate tooling | Review |
| Protomaps/PMTiles | Offline map packaging/rendering | Verify tooling/data obligations | Candidate presentation layer | Review |
| Nominatim | Gazetteer/geocoding | Verify deployment/data obligations | Candidate adapter | Review |
| OpenStreetMap data | Geography | ODbL obligations apply to database use/distribution | Data source | Mandatory attribution/review |

For each approved dependency, add exact repository, version/commit, direct/transitive status, code reused, data included, attribution, commercial implications, SBOM status, reviewer, and date.
