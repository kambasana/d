# Model and Prompt Version Register

Every experiment that uses AI must be able to identify the exact configuration that influenced it.

Record:

- provider adapter and version;
- provider (for example Ollama or OpenRouter);
- model identifier and exact version/quantization when available;
- system/policy prompt version and hash;
- structured output schema version;
- enabled tools/capabilities;
- temperature and sampling parameters;
- random seed where supported;
- retry/fallback chain;
- input/output token counts;
- latency;
- raw output/event reference;
- scenario and branch IDs.

Provider changes during controlled runs require explicit new run/branch metadata.
