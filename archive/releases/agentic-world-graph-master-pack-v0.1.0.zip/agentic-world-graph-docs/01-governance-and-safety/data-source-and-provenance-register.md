# Data Source and Provenance Register

| Dataset ID | Source | Purpose | Coverage/time | Provenance class | Quality/limitations | Licence/restrictions | Status |
|---|---|---|---|---|---|---|---|
| DATA-OSM-001 | OpenStreetMap extract | Geometry, roads, buildings, places, topology inputs | Scenario-defined | Observed external | Coverage/tag completeness varies | ODbL/attribution review | Planned |
| DATA-GAZ-001 | Local Nominatim built from selected OSM extract | Gazetteer/search | Same as OSM build | Derived | Reverse results are nearest indexed object, not physical truth | Inherits data obligations | Planned |
| DATA-TILE-001 | PMTiles generated from approved map sources | Offline visualization | Scenario-defined | Derived projection | Generalized for rendering | Source-dependent | Planned |
| DATA-POP-001 | Population synthesis inputs | Households/agents/cohorts | Scenario-defined | Mixed observed/statistical | Must record source bias and sampling method | Source-dependent | Planned |
| DATA-TIME-001 | Time-use/activity evidence | Schedule calibration | Scenario-defined | External empirical | Population/context dependent | Source-dependent | Planned |

Required fields for production entries: retrieval date, source URL/identifier, transformation pipeline/version, geographic precision, sensitive classification, permitted uses, dependent scenarios, owner, and review date.
