# Agent, Place, and Organization Inspectors

## Agent Inspector sections

1. Identity and provenance
2. Current world state
3. Location/journey
4. Schedule/current action
5. Needs/goals/obligations
6. Relationships/groups/organizations
7. Knowledge/beliefs/claims/evidence
8. Communications/social activity
9. Resources/ownership
10. Recent causal event chain
11. Simulation/model fidelity
12. Model calls relevant to recent decisions

Do not show simulator truth as if the agent knows it. Use separate tabs/labels for `World truth` and `Agent perspective`.

## Place/Building Inspector

- geometry/source/provenance;
- entrances/access;
- occupancy count and exact/aggregate status;
- floors/rooms where available;
- smart objects/affordances;
- organizations/owners/operators;
- resources/capacity;
- active events/incidents;
- movement flows;
- local firehose.

## Organization Inspector

- members/roles;
- leadership/governance;
- resources/property;
- places/territory;
- objectives/policies;
- relationships;
- organizational knowledge vs member knowledge;
- communications;
- current decisions/actions;
- relevant events.

## Cross-selection

Clicking an entity reference should preserve context and allow back-navigation. Selecting a claim from an agent should open the provenance chain; selecting a place should reveal occupants; selecting an organization should reveal members/locations without losing the current simulation time/branch.
