# Accessibility and Inclusive Design

## Requirements

- Keyboard access to map-adjacent controls, lists, inspectors, timeline, and radial/cluster alternatives.
- Every cluster/marker has an accessible label containing count/type/location meaning.
- Provide list/table alternatives for spatial selections and radial expansions.
- Do not rely on color alone for world truth vs belief, warning, uncertainty, or selection.
- Respect reduced-motion settings; cluster merge/split animations must not be required for understanding.
- Support sufficient contrast and scalable text.
- Focus moves predictably when opening inspectors, cluster menus, and building browsers.
- Virtualized data grids retain screen-reader semantics where feasible.
- Map-only information should have textual summaries for selected region/entity.

## Cognitive clarity

Avoid anthropomorphic UI claims that imply sentience or certainty. Use precise labels such as `agent belief`, `simulated state`, `estimated population`, and `model-generated summary`.
