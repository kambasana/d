# 05 - UI and UX

The UI is a projection over authoritative simulation state. It must make scale, provenance, uncertainty, time, branch, and simulation fidelity understandable without implying that visual simplification changes the world.

Core surfaces:

- World Explorer
- Scenario Studio
- Agent Inspector
- Place/Building Inspector
- Organization Inspector
- Information Space
- Timeline/Replay
- Firehose Explorer
- Branch Comparison Workspace
- Validation/Experiment Workspace
