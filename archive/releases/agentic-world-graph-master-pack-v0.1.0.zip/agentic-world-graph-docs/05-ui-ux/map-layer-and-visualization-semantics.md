# Map Layer and Visualization Semantics

## Layer classes

### Base/context
- OSM/PMTiles vector map;
- labels/place names;
- terrain/elevation where packaged;
- administrative boundaries.

### Authoritative world-state projections
- agent positions;
- vehicles;
- journeys/routes;
- building occupancy;
- infrastructure state;
- incidents/interventions.

### Aggregate layers
- population density;
- movement flows;
- congestion;
- resource demand;
- organization influence.

### Information layers
- claim exposure;
- social cascades;
- message paths;
- belief distribution;
- fact-check/correction propagation.

### Analytical layers
- selected cohorts;
- risk states;
- scenario metrics;
- comparison deltas.

## Truth semantics

A layer must state whether it represents:

- exact authoritative state;
- aggregate estimate;
- agent belief;
- inferred analytics;
- scenario assumption;
- historical snapshot.

Do not render agent belief as objective world state without a clear visual distinction.

## Marker rules

- Geographic clusters summarize agents spread across screen-space/geographic bounds.
- Co-location markers represent genuine shared/near-identical place/coordinate occupancy.
- Analytical clusters represent filters and must look distinct from physical clusters.
- Selected/scenario-critical agents may remain individually visible through aggregation, but exceptions must be limited.

## Transition continuity

When zooming, clusters should visually divide/merge in a stable manner so users can follow continuity. Avoid unrelated marker blinking when possible.

## Building transition

At building selection/close zoom, allow transition from map footprint/occupancy to interior hierarchy if interior data exists. Never fabricate detailed interior geometry when unavailable; show level of detail/provenance.
