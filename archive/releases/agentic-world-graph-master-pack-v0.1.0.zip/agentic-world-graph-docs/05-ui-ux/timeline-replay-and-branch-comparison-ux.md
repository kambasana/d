# Timeline, Replay, and Branch Comparison UX

## Timeline

Display:

- simulation time;
- run start/end;
- important domain events;
- interventions;
- snapshots;
- branch points;
- selected-agent/place events;
- communication/claim events when filtered.

## Replay modes

Users should understand whether they are:

- viewing current live state;
- viewing a historical projection;
- replaying recorded events;
- simulating a new branch;
- running with live AI calls.

## Branching interaction

A branch action requires:

1. select time/event boundary;
2. name/describe intervention difference;
3. confirm inherited scenario/configuration;
4. explicitly show changed parameters/plugins/models/seeds;
5. create new branch identity.

## Comparison

Support synchronized map/time, delta metrics, selected-agent comparison, claim diffusion comparison, and side-by-side event timelines.

Avoid suggesting that divergence is caused only by the intervention if random/model configuration also differs.
