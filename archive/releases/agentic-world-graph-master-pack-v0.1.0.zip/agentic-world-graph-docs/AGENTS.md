# AWG Agent Authoring Guide

This repository is the authoritative documentation pack for the Agentic World Graph (AWG) project.

## Mandatory reading order for AI agents

Before creating or editing architecture content, read:

1. `README.md`
2. `01-governance-and-safety/simulation-constitution-and-invariants.md`
3. `glossary-and-controlled-vocabulary.md`
4. `DOCUMENT-MAP.md`
5. The normative specification for the area being changed
6. Relevant ADRs under `06-delivery-and-operations/architecture-decision-records/`

## Rules for AI agents

- Never silently weaken a simulation invariant.
- Never let an LLM become authoritative over physics, time, geography, ownership, resource state, or event truth.
- Keep world truth, agent belief, UI projections, and software telemetry as separate planes.
- Treat OSM/PostGIS/routing data as authoritative spatial sources. PMTiles/Protomaps are presentation and offline distribution layers.
- Every meaningful state change must originate in a typed command, deterministic system transition, or explicit scenario intervention and must emit events.
- Agents may only know facts through valid perception, communication, records, memory, or inference paths.
- Do not equate exposure, understanding, belief, endorsement, posting, liking, commenting, or reposting.
- Do not make every simulated person an always-on LLM process. Use multi-resolution simulation.
- Keep simulation fidelity independent from visualization fidelity.
- Randomness must be typed, seeded, attributable, reproducible, and constrained by model rules.
- Plugin adapters must preserve stable core contracts. Vendor-specific behavior must not leak into the core domain model.
- Offline operation is a first-class deployment requirement.
- Synthetic worlds must still have coherent geometry, topology, places, entrances, routes, occupancy, and traversal rules.
- Claims of realism must be tied to validation evidence. Believable text is not validation.
- Mark assumptions, generated content, inferred data, and observed data distinctly.
- Use existing terminology from the glossary. Do not create synonyms casually.
- Update the requirements traceability matrix when adding a normative requirement.
- Significant architecture decisions require an ADR.
- Update `CHANGELOG.md` when normative behavior changes.

## Document classes

- **Normative**: implementation must comply.
- **Informative**: research, rationale, examples, or planning guidance.
- **Register**: continuously maintained evidence or governance record.
- **Template**: reusable authoring structure.

## Document ID convention

Use stable IDs:

- AWG-VIS: vision and research
- AWG-GOV: governance and safety
- AWG-DOM: domain model
- AWG-PLAT: platform architecture
- AWG-SCN: scenarios and validation
- AWG-UX: UI and UX
- AWG-OPS: delivery and operations
- AWG-CON: machine-readable contracts

Example: `AWG-DOM-003`.

## Requirement ID convention

Use prefixes that indicate the rule family:

- INV: invariant
- GEO: geography and mobility
- AGT: agent runtime
- INF: information and provenance
- EVT: command/event/replay
- PLG: plugin contract
- SCL: scaling
- UX: user experience
- VAL: validation
- SEC: security/privacy
- OPS: operations

Example: `AWG-GEO-014`.

## Editing discipline

When changing a normative rule:

1. identify affected requirements;
2. identify dependent documents;
3. create or update an ADR if the change is architectural;
4. update acceptance criteria;
5. update traceability;
6. update examples if behavior changes;
7. record the change in the changelog.

Do not copy an informative research statement into a normative specification unless the project has explicitly adopted it as a design decision.
