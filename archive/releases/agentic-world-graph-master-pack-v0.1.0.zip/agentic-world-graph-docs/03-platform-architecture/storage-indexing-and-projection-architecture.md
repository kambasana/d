# Storage, Indexing, and Projection Architecture

## Principle

The world graph is semantic, not a mandate for one database.

## Workload-oriented stores

Candidate separation:

- PostGIS: authoritative geometry/spatial queries.
- Relational transactional store: ownership, resources, organizations, structured current state.
- Append-only event store/object files: firehose/event history.
- Columnar analytical store (for example Parquet/DuckDB-style workflows): experiment analysis and replay queries.
- Graph projection/index: relationships, provenance, diffusion paths.
- Search index: text/entity retrieval.
- Vector index: semantic memory/search acceleration only.
- Blob/object storage: media, snapshots, large exports.

## Current state vs history

Current-state tables/read models are projections over validated transitions. Event history remains immutable except for retention policies that are explicitly governed.

## Index requirements

Support efficient queries by:

- world/scenario/branch/time;
- agent/place/organization;
- event/command type;
- claim/source/lineage;
- spatial bounding region;
- journey;
- social post/message;
- model/plugin version.

## Projection rebuild

Derived UI/analytics projections should be rebuildable from authoritative state/event sources where practical. Projection corruption must not rewrite world truth.

## Vector databases

Embedding indexes may retrieve memories/documents but do not own timestamp, identity, source provenance, contradiction status, or causal truth.
