---
title: Multi-Resolution Simulation and Scaling Architecture
document_id: AWG-PLAT-004
status: draft
normative: true
---

# Multi-Resolution Simulation and Scaling Architecture

## Principle

Planetary scope is achieved by simulating relevant entities at appropriate fidelity, not by running every person as a continuously reasoning LLM agent.

## Simulation fidelity levels

```text
S0 - Aggregate population
S1 - Cohort/archetype policy
S2 - Scheduled individual
S3 - Cognitive individual
S4 - Fully embodied local agent
```

### S0 - Aggregate
Counts/flows/distributions for demographics, migration, employment, demand, exposure, disease/risk states, or other macro variables.

### S1 - Cohort/archetype
Shared calibrated policies with distributions and stochastic variation. Suitable for large-scale lower-detail behavior.

### S2 - Scheduled individual
Persistent identity, home/work/household, schedules, resources, relationships, and classical decision systems.

### S3 - Cognitive individual
Detailed memories, beliefs, goals, planning, information diffusion, and occasional AI reasoning.

### S4 - Fully embodied
High-detail local navigation, object interaction, perception, concurrency, collision/occupancy, and fine-grained timing.

## Visualization fidelity

Separate from simulation:

```text
V0 - hidden/aggregate
V1 - heatmap/density
V2 - cluster
V3 - individual map marker
V4 - detailed local/interior avatar/state
```

An S3 agent can appear as V2 when zoomed out. A V3 marker does not imply S3/S4 cognition.

## Promotion

Promoting a cohort/agent to higher fidelity must preserve constraints and provenance. Newly instantiated personal details are tagged synthetic/instantiated, not historical observations.

## Demotion

Compression preserves:

- identity where still required;
- unresolved obligations;
- exceptional state;
- key relationships;
- resource/ownership conservation;
- belief/claim summaries needed for future causality;
- links to full event history.

## Activation

Use event-driven wakeups, schedules, spatial triggers, message delivery, scenario events, and stochastic activation where modelled. Do not poll dormant agents continuously.

## Partitioning

Candidate partitions include spatial cells/regions, organizations/platform shards, or workload-specific services. Cross-partition movement/communication uses explicit handoff/correlation events.

## AI budget

AI usage is a managed resource. Budgets may limit:

- concurrent calls;
- calls per simulated hour;
- calls per agent/day;
- token/latency budgets;
- model class based on task importance/novelty.

Fallback policies preserve simulation integrity when budgets are exhausted.

## Determinism and scale

Distributed execution must distinguish deterministic domain transitions from nondeterministic AI/provider behavior. Record random streams, partition ordering rules, and model call outputs for replay.

## Performance objective style

Avoid vague "million agents" claims. Define benchmark profiles such as:

```text
1M population records
100k S1 cohort-equivalent active updates/hour
10k S2 scheduled individuals in region
1k S3 cognitively detailed agents under scenario load
100 S4 embodied agents in selected local area
```

These numbers are examples for benchmark definition, not committed targets until measured.
