# Deployment Topologies and Offline Operation

## Supported topology classes

### Developer workstation
Single machine, local OSM/PMTiles, local services, Ollama optional. Fast setup and debugging.

### Single-machine offline
All required scenario dependencies installed locally: PostGIS, gazetteer, routing data, PMTiles, simulation runtime, local model if AI is required.

### LAN/private cluster
Distributed simulation/services within a controlled local network. No public internet required.

### Air-gapped
No external network dependency. Data/model/plugin packages are pre-approved and imported through controlled media/processes.

### Hybrid AI
World/geospatial/state remain local while an approved AI adapter may call a remote provider such as OpenRouter. The run records what data crosses the boundary.

### Distributed/cloud
Horizontally scaled regions/services, managed storage/event buses, optional remote model providers.

### Analyst/read-only
Consumes event/projection exports without permissions to mutate scenario/world state.

## Offline bundle

A reproducible offline scenario package should identify:

- OSM extract/version;
- PostGIS import/migrations;
- Nominatim data/build;
- routing tiles/graphs;
- PMTiles;
- local elevation/building supplements if needed;
- models/quantization/runtime;
- plugin binaries/packages;
- scenario definition;
- seeds;
- validation/reference data;
- checksums and licences.

## Network policy

Core services should declare network requirements. "Offline" means required functionality does not silently phone home for analytics, model downloads, fonts, maps, embeddings, or package metadata.

## Recovery

Each topology defines snapshot/backup location, event-log durability, RPO/RTO targets when productionized, and restore verification.
