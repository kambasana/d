---
title: Plugin Adapter SDK and Compatibility Contracts
document_id: AWG-PLAT-003
status: draft
normative: true
---

# Plugin Adapter SDK and Compatibility Contracts

## Goal

Major infrastructure and AI implementations are replaceable without breaking core world behavior or schema meaning.

## Adapter families

```text
AIProviderAdapter
EmbeddingAdapter
MapProjectionAdapter
GazetteerAdapter
RoutingAdapter
MobilityAdapter
LocalNavigationAdapter
PhysicsAdapter
StorageAdapter
EventBusAdapter
SocialPlatformAdapter
EconomyAdapter
WeatherAdapter
AnalyticsAdapter
VisualizationAdapter
AuthenticationAdapter
```

## Contract requirements

Every adapter declares:

- adapter_id and semantic version;
- interface version;
- capabilities;
- configuration schema;
- supported offline/online modes;
- data ownership and persistence behavior;
- timeout/retry semantics;
- deterministic guarantees or lack thereof;
- health/status method;
- error taxonomy;
- resource requirements;
- security/capability permissions;
- licence/provenance metadata;
- compatibility tests.

## Capability negotiation

The core should ask what an adapter can do rather than inspecting vendor names.

Example:

```text
AI capabilities:
- text_generation
- structured_output
- tool_calling
- embeddings
- streaming
- deterministic_seed_support
```

## AI provider boundary

Ollama and OpenRouter implement the same core AI provider interface for relevant capabilities. Agent/runtime code should request functions such as:

```text
propose_intent(...)
rank_options(...)
realize_dialogue(...)
summarize_memories(...)
extract_claims(...)
```

The provider adapter handles API/runtime specifics. Structured outputs are validated before use.

## Spatial adapters

Routing and gazetteer are separate contracts. A place lookup result cannot be assumed traversable without routing/access validation.

## Social platform adapters

Platform adapters define actions, visibility, recommendation/feed behavior, privacy, moderation, and network mechanics. The core information model retains platform-independent claim/message/provenance semantics.

## Plugin lifecycle

```text
discovered -> validated -> enabled -> healthy/degraded -> disabled -> upgraded/rolled back
```

Changing a plugin during a controlled experiment creates explicit configuration/version history.

## Failure rules

- Adapters cannot mutate domain stores outside their granted interface.
- Malformed output fails closed.
- Retries must be idempotent or explicitly correlated.
- Fallbacks are logged.
- No adapter may bypass the simulation constitution.

## Compatibility suite

Each adapter family should ship contract tests that can be run against every implementation. Provider swap is a first-class acceptance test.
