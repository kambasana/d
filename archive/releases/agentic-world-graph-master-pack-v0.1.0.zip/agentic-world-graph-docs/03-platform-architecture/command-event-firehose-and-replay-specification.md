---
title: Command, Event, Firehose, and Replay Specification
document_id: AWG-PLAT-002
status: draft
normative: true
---

# Command, Event, Firehose, and Replay Specification

## Concepts

```text
Intent -> Command -> Validation -> Execution -> Domain Event -> State/Observation/Projection
```

An intent is not proof that an action occurred. A command is not proof of success. Domain events record outcomes.

## Command requirements

Every command has:

- command_id;
- schema_version;
- world_id;
- scenario_id;
- branch_id;
- actor/authority;
- command_type;
- typed arguments;
- issued_at simulation time;
- causal/input references;
- source class (agent, scenario, operator, system);
- optional model provenance;
- idempotency/correlation information where required.

Validation checks schema, authority, preconditions, current state, resource/capacity/access constraints, and relevant domain rules.

## Event envelope

Minimum conceptual envelope:

```yaml
event_id: EVT-...
schema_version: 1
world_id: ...
scenario_id: ...
branch_id: ...
simulation_time: ...
wall_clock_time: ...
sequence: ...
event_type: JourneyStarted
actor_id: ...
target_ids: []
command_id: ...
parent_event_ids: []
caused_by_event_ids: []
location_ref: ...
observation_scope: ...
plugin_ref: ...
random_stream_ref: ...
model_call_ref: ...
provenance: ...
payload: {}
```

## Event families

```text
world.*
agent.*
movement.*
place.*
perception.*
memory.*
belief.*
claim.*
communication.*
social.*
relationship.*
organization.*
economy.*
resource.*
infrastructure.*
scenario.*
model.*
validation.*
```

Infrastructure/software telemetry uses a separate telemetry namespace/plane.

## Firehose

The firehose supports filtered subscription by world, branch, time, event type, actor, place, claim, organization, and other indexed references.

Use cases:

- live UI updates;
- analytics;
- debugging;
- agent/world inspection;
- replay;
- audit;
- scenario comparison;
- future virtual social media clients;
- export to downstream systems.

## Ordering

The platform must define deterministic ordering within a partition/authority scope and explicit causal links across distributed regions. Wall-clock arrival order is not automatically simulation order.

## Snapshots

Snapshots accelerate restore but do not replace the event history needed for causal analysis. A snapshot records:

- event/sequence boundary;
- world/branch;
- schema versions;
- plugin/model configuration references;
- state checksum or equivalent integrity metadata.

## Replay

Replay modes:

### Deterministic core replay
Re-run reducers/systems from recorded commands/events using the same schemas, versions, inputs, and random streams.

### Recorded-AI replay
Use previously recorded model outputs instead of calling Ollama/OpenRouter/other provider again.

### Live-model re-simulation
Explicitly create a new run/branch when a model is re-called. Do not call it the same deterministic replay if outputs can differ.

## Branching

A counterfactual branch:

1. identifies a snapshot/event boundary;
2. reuses immutable prior history;
3. receives a new branch_id;
4. applies one or more declared intervention differences;
5. records all divergent events independently.

## Corrections

Use explicit events such as:

```text
ClaimCorrected
ClaimRetracted
RecordSuperseded
OwnershipTransferred
```

Never delete history merely because current truth/state changed.

## Backpressure and consumers

Firehose consumers must not block the authoritative simulation loop indefinitely. Use buffered/partitioned delivery, replayable offsets, and consumer-specific degradation policies.

## Model calls as provenance

When a model influences an intent, plan, summary, claim extraction, or dialogue, record a model-call reference with provider/model/prompt-policy/schema/fallback metadata.
