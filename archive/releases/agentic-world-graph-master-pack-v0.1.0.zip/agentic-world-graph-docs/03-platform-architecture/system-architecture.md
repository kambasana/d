---
title: System Architecture
document_id: AWG-PLAT-001
status: draft
normative: true
---

# System Architecture

## Architectural stance

AWG is an event-driven simulation platform with a deterministic authoritative core and replaceable adapters around it.

## Core engines

```text
World Runtime
├── World Graph / Domain State
├── Time and Scheduling Engine
├── Geospatial Engine
├── Navigation and Mobility Engine
├── Simulation / Physics / Constraint Engine
├── Agent Runtime
├── Human Systems Engine
├── Information / Epistemic Engine
├── Trust and Reputation Engine
├── Social / Information Platform Engine
├── Organization / Institution Engine
├── Economy / Resource Engine
├── Scenario / Intervention Engine
├── Event Firehose / Replay Engine
└── Projection / Query Engine
```

## Adapter boundary

```text
Core contracts
├── AIProviderAdapter
├── EmbeddingAdapter
├── GazetteerAdapter
├── RoutingAdapter
├── MobilityAdapter
├── LocalNavigationAdapter
├── PhysicsAdapter
├── StorageAdapter
├── EventBusAdapter
├── SocialPlatformAdapter
├── WeatherAdapter
├── AnalyticsAdapter
└── VisualizationAdapter
```

Adapters may be replaced without changing core domain semantics.

## Four data planes

### World truth plane
Authoritative positions, physical/object state, ownership, resources, infrastructure, validated actions, scenario conditions, and simulation clock.

### Agent epistemic plane
Observations, memories, claims, beliefs, trust, uncertainty, contradictions, and information-access history.

### Projection plane
Maps, PMTiles, dashboards, timelines, social feeds, search indexes, clusters, heatmaps, and analytical graph projections.

### Software telemetry plane
CPU/GPU, queue depth, token counts, latency, errors, traces, health, and infrastructure metrics.

Do not merge telemetry with simulation domain events.

## Execution loop

The platform need not use one global high-frequency tick. It can combine event scheduling, fixed-step local systems, and wake-up triggers.

```text
scheduled event / external intervention / agent wake-up
        -> observation/state preparation
        -> decision policy or current action
        -> typed command
        -> validation
        -> deterministic execution
        -> domain events
        -> state reducers
        -> new observations/triggers/projections
```

## Separation of concerns

- AI proposes or interprets within bounded schemas.
- Geospatial/routing systems answer traversability and journey questions.
- Physics/constraint systems resolve physical validity.
- Domain services own state transitions.
- Event service records history.
- Projection services optimize reads and UI.
- Scenario service injects declared interventions but cannot rewrite agent decisions silently.

## Failure model

A failed adapter call cannot partially mutate authoritative state. Commands either fail before commit, emit explicit partial/failure events according to domain rules, or use an approved compensation workflow.

## Offline posture

Core dependencies have local deployment paths. Remote AI providers and external data feeds are optional adapters, not mandatory assumptions.
