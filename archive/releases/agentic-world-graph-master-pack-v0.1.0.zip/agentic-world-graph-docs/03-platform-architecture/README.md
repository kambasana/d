# 03 - Platform Architecture

Normative system boundaries and contracts. These documents implement the constitution and domain semantics without locking the project to one vendor or runtime.

Recommended order:

1. System architecture
2. Command/event/firehose/replay
3. Plugin/adapter SDK
4. Storage/indexing/projections
5. Multi-resolution scaling
6. Deployment/offline operation
